from flask import Flask, render_template, request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import requests, uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

FLW_SECRET_KEY = 'FLWSECK-xxxxxxxxxxxxxxxxxxxxxxx'  # Replace with your Flutterwave key

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(200))
    is_paid = db.Column(db.Boolean, default=False)

class Tip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(500))

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        db.session.add(User(email=email, password=password))
        db.session.commit()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form['email']).first()
        if user and check_password_hash(user.password, request.form['password']):
            session['user_id'] = user.id
            return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    user = User.query.get(session.get('user_id'))
    if not user:
        return redirect('/login')
    if not user.is_paid:
        return redirect('/pay')
    tips = Tip.query.all()
    return render_template('dashboard.html', tips=tips)

@app.route('/pay', methods=['GET', 'POST'])
def pay():
    if request.method == 'POST':
        phone = request.form['phone']
        user = User.query.get(session.get('user_id'))
        tx_ref = str(uuid.uuid4())
        payment = {
            "tx_ref": tx_ref,
            "amount": "10",
            "currency": "USD",
            "payment_options": "mobilemoneyghana",
            "redirect_url": "http://localhost:5000/payment-success",
            "customer": {
                "email": user.email,
                "phonenumber": phone,
                "name": user.email
            },
            "customizations": {
                "title": "Bet Tips",
                "description": "Subscription"
            }
        }
        headers = {
            'Authorization': f'Bearer {FLW_SECRET_KEY}',
            'Content-Type': 'application/json'
        }
        res = requests.post('https://api.flutterwave.com/v3/payments', json=payment, headers=headers)
        return redirect(res.json()['data']['link'])
    return render_template('pay.html')

@app.route('/payment-success')
def payment_success():
    user = User.query.get(session['user_id'])
    user.is_paid = True
    db.session.commit()
    return redirect('/dashboard')

@app.route('/add-tip', methods=['GET', 'POST'])
def add_tip():
    if request.method == 'POST':
        db.session.add(Tip(text=request.form['tip']))
        db.session.commit()
        return redirect('/dashboard')
    return '<form method="post"><textarea name="tip"></textarea><br><button>Add</button></form>'

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
